import 'dotenv/config'
import https from 'https';
import connectToMongoDB from './config/mongo.config.js';
import redisClient from "./config/redis.config.js";
import app from './app.js'
import fs from 'fs';
import {getStorage, initStorage} from "./repositories/storage/storageProvider.js";
import {initWebsocketServer} from "./infrastructure/websocket/websocketServer.js";

const PORT = process.env.PORT || 3000;
const storageRepository = getStorage();

const options = {
    key: fs.readFileSync(process.env.SSL_KEY_PATH),
    cert: fs.readFileSync(process.env.SSL_CERT_PATH),
};

const httpServer = https.createServer(options, app);

Promise.all([
    connectToMongoDB(),
    redisClient.connect(),
    storageRepository.init()
]).then( async ()=>{

    await initWebsocketServer(httpServer);

    httpServer.listen(PORT, ()=>{
        console.log(`Server running on port: ${PORT}`)
    });
}).catch(err => {
    console.log(err)
    process.exit(1);
});

