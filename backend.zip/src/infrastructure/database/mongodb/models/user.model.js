import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
    authId:{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Auth',
      required: true,
      unique: true
    },
    username: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
    },
    fullName: {
        type: String,
        trim: true,
    },
    userBio:{
        type: String,
        trim: true,
    },
    profilePictureKey:{
        type: String,
        trim: true,
    },
    accountStatus:{
        type: String,
        required: true,
        enum: ['active', 'in-active', 'blocked'],
        default: 'in-active'
    }

},{timestamps:true});

const User = mongoose.model('User', userSchema);

export { User };